package studentmgmt;

import java.util.List;
import java.util.Scanner;

public class StudentView {
    private final Scanner scanner = new Scanner(System.in);

    public Student createStudent() {
        Student student = new Student();
        System.out.println("--- Add New Student ---");
        System.out.print("Roll No: ");
        student.setRollNo(scanner.nextLine());
        System.out.print("Name   : ");
        student.setName(scanner.nextLine());
        System.out.print("Course : ");
        student.setCourse(scanner.nextLine());
        return student;
    }

    public void displayStudents(List<Student> students) {
        System.out.println("\n--- Student List ---");
        for (Student student : students) {
            System.out.println("Roll No: " + student.getRollNo());
            System.out.println("Name   : " + student.getName());
            System.out.println("Course : " + student.getCourse());
            System.out.println("----------------------");
        }
    }

    public String getRollNoForUpdate() {
        System.out.print("Enter the Roll No of the student to update: ");
        return scanner.nextLine();
    }

    public void updateStudentDetails(Student student) {
        System.out.println("Updating student: " + student.getName());
        System.out.print("New Name   : ");
        student.setName(scanner.nextLine());
        System.out.print("New Course : ");
        student.setCourse(scanner.nextLine());
    }

    public void showMessage(String message) {
        System.out.println(message);
    }
}
