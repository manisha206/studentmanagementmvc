package studentmgmt;

import java.util.ArrayList;
import java.util.List;

public class StudentController {
    private final List<Student> students;
    private final StudentView view;

    public StudentController() {
        students = new ArrayList<>();
        view = new StudentView();
    }

    public void addStudent() {
        Student student = view.createStudent();
        students.add(student);
        view.showMessage("Student added successfully!");
    }

    public void displayStudents() {
        if (students.isEmpty()) {
            view.showMessage("No students found.");
        } else {
            view.displayStudents(students);
        }
    }

    public void updateStudent() {
        String rollNoToUpdate = view.getRollNoForUpdate();
        for (Student student : students) {
            if (student.getRollNo().equalsIgnoreCase(rollNoToUpdate)) {
                view.updateStudentDetails(student);
                view.showMessage("Student updated successfully!");
                return;
            }
        }
        view.showMessage("Student not found.");
    }
}
